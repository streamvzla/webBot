@extends('admin.layouts.app')

@section('title', 'Correos Autorizados - Panel de Administración')
@section('header', 'Correos Autorizados')
@section('description', 'Gestiona los correos permitidos para consultas')

@section('content')

<div class="glass-panel rounded-2xl p-6 md:p-8 mb-8 animate-fade-in-up">
    <div class="flex flex-col lg:flex-row lg:items-end justify-between gap-6">
        <form method="GET" class="flex-1 grid grid-cols-1 md:grid-cols-2 xl:grid-cols-5 gap-4 items-end w-full">
            <div class="w-full">
                <label class="block text-sm font-medium text-slate-400 uppercase tracking-wider mb-2">Buscar</label>
                <div class="relative">
                    <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                        <svg class="h-5 w-5 text-slate-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"></path></svg>
                    </div>
                    <input type="text" name="search" value="{{ request('search') }}"
                        class="input-premium pl-10"
                        placeholder="Correo electrónico...">
                </div>
            </div>
            
            <div class="w-full">
                <label class="block text-sm font-medium text-slate-400 uppercase tracking-wider mb-2">Asignación (CRM)</label>
                <select name="assignment" class="input-premium appearance-none bg-[url('data:image/svg+xml;charset=US-ASCII,%3Csvg%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20width%3D%22292.4%22%20height%3D%22292.4%22%3E%3Cpath%20fill%3D%22%2394a3b8%22%20d%3D%22M287%2069.4a17.6%2017.6%200%200%200-13-5.4H18.4c-5%200-9.3%201.8-12.9%205.4A17.6%2017.6%200%200%200%200%2082.2c0%205%201.8%209.3%205.4%2012.9l128%20127.9c3.6%203.6%207.8%205.4%2012.8%205.4s9.2-1.8%2012.8-5.4L287%2095c3.5-3.5%205.4-7.8%205.4-12.8%200-5-1.9-9.2-5.5-12.8z%22%2F%3E%3C%2Fsvg%3E')] bg-[length:0.7rem_auto] bg-no-repeat bg-[position:right_1rem_center] pr-10">
                    <option value="">Todas las cuentas</option>
                    <option value="free" {{ request('assignment') === 'free' ? 'selected' : '' }}>Libres (Sin Asignar)</option>
                    <option value="assigned" {{ request('assignment') === 'assigned' ? 'selected' : '' }}>Asignadas</option>
                </select>
            </div>

            <div class="w-full">
                <label class="block text-sm font-medium text-slate-400 uppercase tracking-wider mb-2">Público</label>
                <select name="public" class="input-premium appearance-none bg-[url('data:image/svg+xml;charset=US-ASCII,%3Csvg%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20width%3D%22292.4%22%20height%3D%22292.4%22%3E%3Cpath%20fill%3D%22%2394a3b8%22%20d%3D%22M287%2069.4a17.6%2017.6%200%200%200-13-5.4H18.4c-5%200-9.3%201.8-12.9%205.4A17.6%2017.6%200%200%200%200%2082.2c0%205%201.8%209.3%205.4%2012.9l128%20127.9c3.6%203.6%207.8%205.4%2012.8%205.4s9.2-1.8%2012.8-5.4L287%2095c3.5-3.5%205.4-7.8%205.4-12.8%200-5-1.9-9.2-5.5-12.8z%22%2F%3E%3C%2Fsvg%3E')] bg-[length:0.7rem_auto] bg-no-repeat bg-[position:right_1rem_center] pr-10">
                    <option value="">Todos</option>
                    <option value="1" {{ request('public') === '1' ? 'selected' : '' }}>Sí</option>
                    <option value="0" {{ request('public') === '0' ? 'selected' : '' }}>No</option>
                </select>
            </div>
            
            @if(auth()->user()->role === 'admin')
            <div class="w-full">
                <label class="block text-sm font-medium text-slate-400 uppercase tracking-wider mb-2">Usuario Padre</label>
                <select name="user_id" class="input-premium appearance-none bg-[url('data:image/svg+xml;charset=US-ASCII,%3Csvg%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20width%3D%22292.4%22%20height%3D%22292.4%22%3E%3Cpath%20fill%3D%22%2394a3b8%22%20d%3D%22M287%2069.4a17.6%2017.6%200%200%200-13-5.4H18.4c-5%200-9.3%201.8-12.9%205.4A17.6%2017.6%200%200%200%200%2082.2c0%205%201.8%209.3%205.4%2012.9l128%20127.9c3.6%203.6%207.8%205.4%2012.8%205.4s9.2-1.8%2012.8-5.4L287%2095c3.5-3.5%205.4-7.8%205.4-12.8%200-5-1.9-9.2-5.5-12.8z%22%2F%3E%3C%2Fsvg%3E')] bg-[length:0.7rem_auto] bg-no-repeat bg-[position:right_1rem_center] pr-10">
                    <option value="">Todos los usuarios</option>
                    @foreach($users as $u)
                        <option value="{{ $u->id }}" {{ request('user_id') == $u->id ? 'selected' : '' }}>{{ $u->name }}</option>
                    @endforeach
                </select>
            </div>
            @endif
            
            <div class="w-full">
                <label class="block text-sm font-medium text-slate-400 uppercase tracking-wider mb-2">Plataforma</label>
                <select name="platform_id" class="input-premium appearance-none bg-[url('data:image/svg+xml;charset=US-ASCII,%3Csvg%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20width%3D%22292.4%22%20height%3D%22292.4%22%3E%3Cpath%20fill%3D%22%2394a3b8%22%20d%3D%22M287%2069.4a17.6%2017.6%200%200%200-13-5.4H18.4c-5%200-9.3%201.8-12.9%205.4A17.6%2017.6%200%200%200%200%2082.2c0%205%201.8%209.3%205.4%2012.9l128%20127.9c3.6%203.6%207.8%205.4%2012.8%205.4s9.2-1.8%2012.8-5.4L287%2095c3.5-3.5%205.4-7.8%205.4-12.8%200-5-1.9-9.2-5.5-12.8z%22%2F%3E%3C%2Fsvg%3E')] bg-[length:0.7rem_auto] bg-no-repeat bg-[position:right_1rem_center] pr-10">
                    <option value="">Todas las plataformas</option>
                    @foreach($platformsFilter as $platform)
                        <option value="{{ $platform->id }}" {{ request('platform_id') == $platform->id ? 'selected' : '' }}>{{ $platform->name }}</option>
                    @endforeach
                </select>
            </div>
            
            <div class="col-span-full xl:col-span-4 flex gap-3 mt-2">
                <button type="submit" class="bg-slate-800 hover:bg-slate-700 text-white font-medium py-3 px-6 rounded-xl transition duration-300 border border-slate-700 flex-1 sm:flex-none">
                    Aplicar Filtros
                </button>
                
                @if(request()->anyFilled(['search', 'public', 'status', 'user_id', 'platform_id']))
                    <a href="{{ route('admin.allowed-emails.index') }}" class="bg-red-500/10 hover:bg-red-500/20 text-red-400 font-medium py-3 px-4 rounded-xl transition duration-300 border border-red-500/20 flex items-center justify-center" title="Limpiar filtros">
                        <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path></svg>
                    </a>
                @endif
            </div>
        </form>
        
        <div class="w-full lg:w-auto flex-shrink-0 mt-4 lg:mt-0 border-t border-slate-700/50 pt-4 lg:border-t-0 lg:pt-0 flex flex-col sm:flex-row gap-3">
            <a href="{{ route('admin.allowed-emails.mass-upload') }}" class="w-full sm:w-auto bg-slate-800 hover:bg-slate-700 text-white font-medium py-3 px-6 rounded-xl transition duration-300 border border-slate-700 flex items-center justify-center gap-2">
                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-8l-4-4m0 0L8 8m4-4v12"></path></svg>
                Carga Masiva
            </a>
            <a href="{{ route('admin.allowed-emails.create') }}" class="btn-premium w-full sm:w-auto flex items-center justify-center gap-2">
                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"></path></svg>
                Autorizar Nuevo Correo
            </a>
        </div>
    </div>
</div>

<div class="glass-panel rounded-2xl overflow-hidden animate-fade-in-up" style="animation-delay: 0.1s;">
    @if($allowedEmails->count() > 0)
        <div class="overflow-x-auto">
            <table class="w-full text-left border-collapse">
                <thead>
                    <tr class="bg-slate-900 border-b border-slate-700/50">
                        <th class="px-6 py-4 text-xs font-semibold text-slate-400 uppercase tracking-wider">Correo Vinculado</th>
                        @if(auth()->user()->role === 'admin')
                        <th class="px-6 py-4 text-xs font-semibold text-slate-400 uppercase tracking-wider">Usuario Padre</th>
                        @endif
                        <th class="px-6 py-4 text-xs font-semibold text-slate-400 uppercase tracking-wider">Plataforma</th>
                        <th class="px-6 py-4 text-xs font-semibold text-slate-400 uppercase tracking-wider text-center">Visibilidad</th>
                        <th class="px-6 py-4 text-xs font-semibold text-slate-400 uppercase tracking-wider text-center">Estado</th>
                        <th class="px-6 py-4 text-xs font-semibold text-slate-400 uppercase tracking-wider text-right">Administrar</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-slate-800/50">
                    @foreach($allowedEmails as $email)
                        <tr class="hover:bg-slate-800/30 transition duration-200 group">
                            <td class="px-6 py-5">
                                <div class="flex items-center gap-4">
                                    <div class="w-12 h-12 rounded-xl bg-gradient-to-br from-indigo-500/20 to-purple-500/20 flex items-center justify-center border border-indigo-500/20 flex-shrink-0 group-hover:scale-110 transition duration-300">
                                        <svg class="w-6 h-6 text-indigo-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"/>
                                        </svg>
                                    </div>
                                    <div>
                                        <p class="font-bold text-white text-base group-hover:text-indigo-400 transition">{{ $email->email }}</p>
                                        <p class="text-xs text-slate-500 mt-0.5">Creado: {{ $email->created_at->format('d/m/Y') }}</p>
                                    </div>
                                </div>
                            </td>
                            @if(auth()->user()->role === 'admin')
                            <td class="px-6 py-5">
                                @if($email->user)
                                    <div class="flex items-center gap-3">
                                        <div class="w-8 h-8 rounded-full bg-slate-800 flex items-center justify-center border border-slate-700">
                                            <svg class="w-4 h-4 text-slate-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"/>
                                            </svg>
                                        </div>
                                        <div>
                                            <p class="font-medium text-slate-300 text-sm">{{ $email->user->name }}</p>
                                            <p class="text-[10px] text-slate-500">{{ $email->user->email }}</p>
                                        </div>
                                    </div>
                                @else
                                    <span class="text-sm text-slate-500 italic">Sistema</span>
                                @endif
                            </td>
                            @endif
                            <td class="px-6 py-5">
                                @if($email->platform)
                                    <div class="flex items-center gap-3">
                                        @if($email->platform->logo)
                                            <img src="{{ asset('storage/' . $email->platform->logo) }}" alt="{{ $email->platform->name }}" class="w-8 h-8 rounded-lg object-cover border border-slate-700/50">
                                        @else
                                            <div class="w-8 h-8 rounded-lg flex items-center justify-center border border-slate-700/50" style="background-color: {{ $email->platform->color ?? '#6366f1' }}">
                                                <span class="text-white text-xs font-bold">{{ substr($email->platform->name, 0, 2) }}</span>
                                            </div>
                                        @endif
                                        <span class="text-sm font-medium text-slate-300">{{ $email->platform->name }}</span>
                                    </div>
                                @else
                                    <span class="text-sm text-slate-500 italic">Sin plataforma</span>
                                @endif
                            </td>
                            <td class="px-6 py-5 text-center">
                                @if($email->is_public)
                                    <div class="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-blue-500/10 border border-blue-500/20">
                                        <svg class="w-3 h-3 text-blue-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 12a9 9 0 01-9 9m9-9a9 9 0 00-9-9m9 9H3m9 9a9 9 0 01-9-9m9 9c1.657 0 3-4.03 3-9s-1.343-9-3-9m0 18c-1.657 0-3-4.03-3-9s1.343-9 3-9m-9 9a9 9 0 019-9"/>
                                        </svg>
                                        <span class="text-blue-400 text-xs font-bold uppercase tracking-wider">Público</span>
                                    </div>
                                @else
                                    <div class="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-slate-500/10 border border-slate-500/20">
                                        <svg class="w-3 h-3 text-slate-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z"></path></svg>
                                        <span class="text-slate-400 text-xs font-bold uppercase tracking-wider">Privado</span>
                                    </div>
                                @endif
                            </td>
                            <td class="px-6 py-5 text-center">
                                @if($email->is_active)
                                    <div class="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/20">
                                        <span class="w-2 h-2 rounded-full bg-emerald-500 shadow-[0_0_8px_rgba(16,185,129,0.8)]"></span>
                                        <span class="text-emerald-400 text-xs font-bold uppercase tracking-wider">Activo</span>
                                    </div>
                                @else
                                    <div class="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-red-500/10 border border-red-500/20">
                                        <span class="w-2 h-2 rounded-full bg-red-500 shadow-[0_0_8px_rgba(239,68,68,0.8)]"></span>
                                        <span class="text-red-400 text-xs font-bold uppercase tracking-wider">Inactivo</span>
                                    </div>
                                @endif
                            </td>
                            <td class="px-6 py-5">
                                <div class="flex items-center justify-end gap-3">
                                    <a href="{{ route('admin.allowed-emails.edit', $email) }}" class="p-2 rounded-lg bg-slate-800 hover:bg-indigo-500 hover:text-white text-slate-400 transition duration-300 border border-slate-700" title="Editar Correo">
                                        <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z"/>
                                        </svg>
                                    </a>
                                    <form action="{{ route('admin.allowed-emails.destroy', $email) }}" method="POST" class="inline">
                                        @csrf
                                        @method('DELETE')
                                        <button type="submit" class="p-2 rounded-lg bg-slate-800 hover:bg-red-500 hover:text-white text-slate-400 transition duration-300 border border-slate-700" title="Eliminar Correo" onclick="return confirm('¿Confirma la eliminación permanente de este correo autorizado?')">
                                            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 1 0 00-1 1v3M4 7h16"/>
                                            </svg>
                                        </button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
        @if($allowedEmails->hasPages())
            <div class="p-4 border-t border-slate-700/50 bg-slate-900/30">
                {{ $allowedEmails->appends(request()->query())->links() }}
            </div>
        @endif
    @else
        <div class="flex flex-col items-center justify-center py-16 text-slate-500">
            <div class="w-24 h-24 rounded-full bg-slate-800 flex items-center justify-center mb-4 border border-slate-700/50">
                <svg class="w-12 h-12 opacity-50" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"/>
                </svg>
            </div>
            <h3 class="text-lg font-medium text-slate-300">No hay correos autorizados</h3>
            <p class="text-sm mt-1 mb-6 text-center max-w-md">Registra los correos que los clientes podrán consultar para obtener sus códigos.</p>
            <a href="{{ route('admin.allowed-emails.create') }}" class="btn-premium">
                Autorizar Primer Correo
            </a>
        </div>
    @endif
</div>
@endsection

