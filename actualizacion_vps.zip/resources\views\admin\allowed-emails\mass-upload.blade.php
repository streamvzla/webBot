@extends('admin.layouts.app')

@section('title', 'Carga Masiva de Correos - Panel de Administración')
@section('header', 'Carga Masiva de Correos')
@section('description', 'Sube cientos de correos a la vez para una plataforma')

@section('content')
<div class="max-w-4xl mx-auto">
    <div class="bg-slate-900 border border-slate-800 rounded-xl p-6 shadow-sm mb-6 animate-fade-in-up">
        
        @if ($errors->any())
            <div class="mb-6 p-4 rounded-lg bg-red-500/10 border border-red-500/20 text-red-400">
                <div class="flex items-center gap-2 mb-2 font-medium">
                    <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"></path></svg>
                    Por favor, corrige los siguientes errores:
                </div>
                <ul class="list-disc list-inside text-sm">
                    @foreach ($errors->all() as $error)
                        <li>{{ $error }}</li>
                    @endforeach
                </ul>
            </div>
        @endif

        <form action="{{ route('admin.allowed-emails.mass-store') }}" method="POST" class="space-y-6">
            @csrf
            
            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                <!-- Plataforma -->
                <div>
                    <label for="platform_id" class="block text-sm font-medium text-slate-300 mb-2">Plataforma (Opcional)</label>
                    <select id="platform_id" name="platform_id" class="w-full px-4 py-3 rounded-lg bg-slate-950 border border-slate-800 text-white focus:outline-none focus:border-violet-500 focus:ring-1 focus:ring-violet-500 transition">
                        <option value="">-- Sin plataforma específica --</option>
                        @foreach($platforms as $platform)
                            <option value="{{ $platform->id }}" {{ old('platform_id') == $platform->id ? 'selected' : '' }}>
                                {{ $platform->name }}
                            </option>
                        @endforeach
                    </select>
                    <p class="text-xs text-slate-500 mt-2">Si dejas esto en blanco, los correos servirán para cualquier plataforma genérica.</p>
                </div>

                <!-- Opciones -->
                <div class="space-y-4 pt-8">
                    <label class="flex items-center cursor-pointer group">
                        <input type="hidden" name="is_active" value="0">
                        <input type="checkbox" name="is_active" value="1" {{ old('is_active', true) ? 'checked' : '' }}
                            class="w-5 h-5 text-violet-500 bg-slate-950 border-slate-800 rounded focus:ring-violet-500 focus:ring-2 cursor-pointer transition">
                        <span class="ml-3 text-slate-300 group-hover:text-white transition">Activos inmediatamente</span>
                    </label>

                    <label class="flex items-center cursor-pointer group">
                        <input type="hidden" name="is_public" value="0">
                        <input type="checkbox" name="is_public" value="1" {{ old('is_public') ? 'checked' : '' }}
                            class="w-5 h-5 text-violet-500 bg-slate-950 border-slate-800 rounded focus:ring-violet-500 focus:ring-2 cursor-pointer transition">
                        <div class="ml-3">
                            <span class="text-slate-300 group-hover:text-white transition block">Correos Públicos</span>
                            <span class="text-xs text-slate-500">Disponibles para otros usuarios (si eres franquicia)</span>
                        </div>
                    </label>
                </div>
            </div>

            <!-- Caja de texto masiva -->
            <div class="mt-6">
                <label for="emails_text" class="block text-sm font-medium text-slate-300 mb-2">Pega aquí los correos</label>
                <div class="bg-violet-500/10 border border-violet-500/20 rounded-lg p-3 mb-3 text-xs text-violet-300 flex items-start gap-2">
                    <svg class="w-4 h-4 flex-shrink-0 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>
                    Puedes pegar texto desde Excel, blocs de notas o separados por comas. El sistema extraerá automáticamente todo lo que parezca un correo electrónico e ignorará duplicados o palabras sueltas.
                </div>
                <textarea id="emails_text" name="emails_text" rows="12" required
                    class="w-full px-4 py-3 rounded-lg bg-slate-950 border border-slate-800 text-emerald-400 font-mono text-sm placeholder-slate-600 focus:outline-none focus:border-violet-500 focus:ring-1 focus:ring-violet-500 transition"
                    placeholder="ejemplo1@netflix.com, ejemplo2@netflix.com&#10;ejemplo3@netflix.com">{{ old('emails_text') }}</textarea>
            </div>

            <div class="flex gap-4 pt-4 border-t border-slate-800 mt-6">
                <a href="{{ route('admin.allowed-emails.index') }}" class="flex-1 bg-slate-800 hover:bg-slate-700 text-white font-medium py-3 px-6 rounded-lg text-center transition border border-slate-700">
                    Cancelar
                </a>
                <button type="submit" class="flex-1 bg-violet-600 hover:bg-violet-500 text-white font-medium py-3 px-6 rounded-lg transition shadow-sm flex justify-center items-center gap-2">
                    <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-8l-4-4m0 0L8 8m4-4v12"></path></svg>
                    Procesar Carga Masiva
                </button>
            </div>
        </form>
    </div>
</div>
@endsection
