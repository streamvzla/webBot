<div>
    @section('header', 'Gestor de Licencias')
    @section('description', 'Administra y emite firmas digitales vitalicias para Codebot')

    <!-- Header Actions -->
    <div class="flex flex-col md:flex-row justify-between items-center gap-4 mb-6">
        <div class="flex items-center gap-2 w-full md:w-auto">
            <div class="relative w-full md:w-64">
                <div class="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
                    <svg class="w-4 h-4 text-slate-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"></path></svg>
                </div>
                <input wire:model.live.debounce.300ms="search" type="text" class="bg-slate-950 border border-slate-800 text-slate-300 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 block w-full pl-10 p-2.5 placeholder-slate-500" placeholder="Buscar clave o dominio...">
            </div>
            <select wire:model.live="statusFilter" class="bg-slate-950 border border-slate-800 text-slate-300 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 block p-2.5">
                <option value="">Todos los Estados</option>
                <option value="active">Activas</option>
                <option value="suspended">Suspendidas</option>
                <option value="revoked">Revocadas</option>
            </select>
        </div>

        <button wire:click="create" class="w-full md:w-auto bg-violet-600 hover:bg-violet-500 text-white font-medium rounded-lg text-sm px-5 py-2.5 flex items-center justify-center gap-2 transition-all">
            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6v6m0 0v6m0-6h6m-6 0H6"></path></svg>
            Emitir Nueva Licencia
        </button>
    </div>

    <!-- Table -->
    <div class="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden shadow-lg">
        <div class="overflow-x-auto">
            <table class="w-full text-sm text-left text-slate-400">
                <thead class="text-xs text-slate-500 uppercase bg-slate-900/50 border-b border-slate-700/50">
                    <tr>
                        <th scope="col" class="px-6 py-4">Clave de Licencia</th>
                        <th scope="col" class="px-6 py-4">Dominio Vinculado</th>
                        <th scope="col" class="px-6 py-4">Cliente</th>
                        <th scope="col" class="px-6 py-4">Estado</th>
                        <th scope="col" class="px-6 py-4">F. Creación</th>
                        <th scope="col" class="px-6 py-4 text-right">Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse($licenses as $license)
                    <tr class="border-b border-slate-700/30 hover:bg-slate-700/20 transition-colors">
                        <td class="px-6 py-4 font-mono text-violet-400 font-medium">
                            {{ $license->license_key }}
                        </td>
                        <td class="px-6 py-4 text-white">
                            @if($license->domain)
                                <span class="bg-slate-700 px-2 py-1 rounded text-xs">{{ $license->domain }}</span>
                            @else
                                <span class="text-slate-500 italic">Sin vincular</span>
                            @endif
                        </td>
                        <td class="px-6 py-4">
                            <div class="flex flex-col">
                                <span class="text-white">{{ $license->client_name ?: 'N/A' }}</span>
                                <span class="text-xs text-slate-500">{{ $license->client_email }}</span>
                            </div>
                        </td>
                        <td class="px-6 py-4">
                            @if($license->status === 'active')
                                <span class="bg-violet-500/10 text-violet-400 border border-violet-500/20 px-2.5 py-0.5 rounded text-xs font-medium uppercase tracking-wider">Activa</span>
                            @elseif($license->status === 'suspended')
                                <span class="bg-amber-500/10 text-amber-400 border border-amber-500/20 px-2.5 py-0.5 rounded text-xs font-medium uppercase tracking-wider">Suspendida</span>
                            @else
                                <span class="bg-red-500/10 text-red-400 border border-red-500/20 px-2.5 py-0.5 rounded text-xs font-medium uppercase tracking-wider">Revocada</span>
                            @endif
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap text-xs">
                            {{ $license->created_at->format('d M, Y') }}
                        </td>
                        <td class="px-6 py-4 text-right">
                            <div class="flex justify-end gap-2">
                                <button wire:click="edit({{ $license->id }})" class="p-2 text-slate-400 hover:text-white bg-slate-700/50 hover:bg-slate-600 rounded-lg transition" title="Editar Licencia">
                                    <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z"></path></svg>
                                </button>
                                <button onclick="confirm('¿Estás seguro de borrar permanentemente esta licencia? Esta acción no se puede deshacer y el cliente perderá el acceso.') || event.stopImmediatePropagation()" wire:click="deleteLicense({{ $license->id }})" class="p-2 text-red-400 hover:text-white bg-red-500/10 hover:bg-red-500 rounded-lg transition" title="Borrar Licencia">
                                    <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"></path></svg>
                                </button>
                            </div>
                        </td>
                    </tr>
                    @empty
                    <tr>
                        <td colspan="6" class="px-6 py-12 text-center">
                            <svg class="mx-auto h-12 w-12 text-slate-600 mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"></path></svg>
                            <h3 class="text-lg font-medium text-slate-300">No hay licencias</h3>
                            <p class="text-slate-500 mt-1">Genera tu primera licencia para empezar a vender Codebot.</p>
                        </td>
                    </tr>
                    @endforelse
                </tbody>
            </table>
        </div>
        @if($licenses->hasPages())
        <div class="p-4 border-t border-slate-700/50">
            {{ $licenses->links() }}
        </div>
        @endif
    </div>

    <!-- Modal Form (Create / Edit) -->
    @if($showModal)
    <div class="fixed inset-0 z-50 overflow-y-auto" aria-labelledby="modal-title" role="dialog" aria-modal="true">
        <div class="flex items-center justify-center min-h-screen px-4 pt-4 pb-20 text-center sm:p-0">
            
            <div class="fixed inset-0 transition-opacity bg-slate-900/80 backdrop-blur-sm" aria-hidden="true" wire:click="$set('showModal', false)"></div>

            <div class="relative inline-block overflow-hidden text-left align-bottom transition-all transform bg-slate-900 border border-slate-800 rounded-xl shadow-2xl sm:my-8 sm:align-middle sm:max-w-lg w-full">
                <div class="px-6 py-4 border-b border-slate-800 flex justify-between items-center bg-slate-950">
                    <h3 class="text-lg font-semibold text-white" id="modal-title">
                        {{ $isEditing ? 'Editar Licencia' : 'Emitir Licencia' }}
                    </h3>
                    <button wire:click="$set('showModal', false)" class="text-slate-400 hover:text-white">
                        <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path></svg>
                    </button>
                </div>
                
                <form wire:submit.prevent="save">
                    <div class="px-6 py-6 space-y-5">
                        
                        <!-- Clave de Licencia -->
                        <div>
                            <label class="block text-sm font-medium text-slate-300 mb-1">Clave de Licencia</label>
                            <div class="flex">
                                <input wire:model="license_key" type="text" class="bg-slate-950 border border-slate-800 text-violet-400 font-mono text-sm rounded-l-lg focus:ring-violet-500 focus:border-violet-500 block w-full p-2.5" {{ $isEditing ? 'readonly' : '' }}>
                                @if(!$isEditing)
                                <button type="button" wire:click="generateKey" class="bg-slate-800 hover:bg-slate-700 text-white px-4 border border-l-0 border-slate-800 rounded-r-lg text-sm transition">
                                    Generar
                                </button>
                                @endif
                            </div>
                            @error('license_key') <span class="text-red-400 text-xs mt-1 block">{{ $message }}</span> @enderror
                        </div>

                        <!-- Dominio Autorizado -->
                        <div>
                            <label class="block text-sm font-medium text-slate-300 mb-1">Dominio Autorizado (Editar Dominio)</label>
                            <input wire:model="domain" type="text" placeholder="ejemplo.com" class="bg-slate-950 border border-slate-800 text-white text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 block w-full p-2.5">
                            <p class="text-xs text-slate-500 mt-1">Si dejas esto en blanco, Codebot registrará el primer dominio donde se instale automáticamente.</p>
                            @error('domain') <span class="text-red-400 text-xs mt-1 block">{{ $message }}</span> @enderror
                        </div>

                        <!-- Cliente y Estado (Grid) -->
                        <div class="grid grid-cols-2 gap-4">
                            <div>
                                <label class="block text-sm font-medium text-slate-300 mb-1">Nombre del Cliente</label>
                                <input wire:model="client_name" type="text" class="bg-slate-950 border border-slate-800 text-white text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 block w-full p-2.5">
                            </div>
                            <div>
                                <label class="block text-sm font-medium text-slate-300 mb-1">Estado</label>
                                <select wire:model="status" class="bg-slate-950 border border-slate-800 text-white text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 block w-full p-2.5">
                                    <option value="active">Activa</option>
                                    <option value="suspended">Suspendida</option>
                                    <option value="revoked">Revocada</option>
                                </select>
                            </div>
                        </div>

                        <!-- Notas -->
                        <div>
                            <label class="block text-sm font-medium text-slate-300 mb-1">Notas Privadas</label>
                            <textarea wire:model="notes" rows="2" class="bg-slate-950 border border-slate-800 text-white text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 block w-full p-2.5"></textarea>
                        </div>
                    </div>
                    
                    <div class="px-6 py-4 border-t border-slate-800 bg-slate-950 flex justify-end gap-3">
                        <button type="button" wire:click="$set('showModal', false)" class="text-slate-300 bg-transparent hover:bg-slate-700 border border-slate-600 font-medium rounded-lg text-sm px-5 py-2.5 transition">
                            Cancelar
                        </button>
                        <button type="submit" class="text-white bg-violet-600 hover:bg-violet-500 font-medium rounded-lg text-sm px-5 py-2.5 shadow-sm transition">
                            {{ $isEditing ? 'Guardar Cambios' : 'Emitir Licencia' }}
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    @endif
</div>
