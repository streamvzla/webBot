<?php

use App\Http\Controllers\AuthController;
use App\Http\Controllers\HomeController;
use App\Models\Client;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
*/

// Install Routes
Route::prefix('install')->name('install.')->group(function () {
    Route::get('/', [App\Http\Controllers\InstallController::class, 'welcome'])->name('step1');
    Route::get('/requirements', [App\Http\Controllers\InstallController::class, 'requirements'])->name('requirements');
    Route::get('/database', [App\Http\Controllers\InstallController::class, 'database'])->name('database');
    Route::post('/database', [App\Http\Controllers\InstallController::class, 'databasePost'])->name('database.post');
    Route::get('/admin', [App\Http\Controllers\InstallController::class, 'admin'])->name('admin');
    Route::post('/process', [App\Http\Controllers\InstallController::class, 'process'])->name('process');
    Route::get('/finish', [App\Http\Controllers\InstallController::class, 'finish'])->name('finish');
});

// Home - Redirigir al login
Route::get('/', [AuthController::class, 'showLogin'])->name('home');

// Cron Job Route - Reset query counts daily
Route::get('/cron', function () {
    $token = request('token');
    $expectedToken = env('CRON_TOKEN', 'your-secure-token-here');

    if ($token !== $expectedToken) {
        abort(403, 'Token inválido');
    }

    $resetCount = Client::where('query_count', '>', 0)->update(['query_count' => 0]);

    return response()->json([
        'success' => true,
        'message' => "Se han reseteado {$resetCount} contador(es) de consultas.",
        'timestamp' => now()->toIso8601String()
    ]);
})->name('cron.job');

// Public Query Routes (sin autenticación)
Route::prefix('query')->name('public.')->middleware([\App\Http\Middleware\CheckIpBan::class])->group(function () {
    Route::get('/', [App\Http\Controllers\Public\PublicQueryController::class, 'index'])->name('query');
    Route::post('/', [App\Http\Controllers\Public\PublicQueryController::class, 'query'])->name('query.submit');
});

// Páginas de Información
Route::get('/guia', function () {
    return view('pages.guia');
})->name('guia');

Route::get('/acerca-de', function () {
    return view('pages.acerca');
})->name('acerca');

// Authentication Routes (handles both client and admin)
Route::get('/login', [AuthController::class, 'showLogin'])->name('login');
Route::post('/login', [AuthController::class, 'login'])->name('login.post');
Route::post('/logout', [AuthController::class, 'logout'])->name('logout');

// 2FA Verification during login
Route::get('/2fa/verify', [App\Http\Controllers\TwoFactorController::class, 'showVerifyForm'])->name('2fa.verify');
Route::post('/2fa/verify', [App\Http\Controllers\TwoFactorController::class, 'verifyLogin'])->name('2fa.verify.post');

// Crear usuario rápidamente desde login (rol 'user' automático)
Route::post('/admin/users/quick-create', [App\Http\Controllers\Admin\UserController::class, 'createQuick'])->name('admin.users.quick-create');

// Admin Routes (protected)
Route::prefix('admin')->middleware(['auth'])->group(function () {
    Route::get('/dashboard', [App\Http\Controllers\Admin\DashboardController::class, 'index'])->name('admin.dashboard');
    Route::get('/settings', [App\Http\Controllers\Admin\SettingsController::class, 'index'])->name('admin.settings');
    Route::put('/settings', [App\Http\Controllers\Admin\SettingsController::class, 'update'])->name('admin.settings.update')->middleware(['auth', \App\Http\Middleware\CheckUserRole::class.':admin']);

    // Storage Link - Verificar y recrear link simbólico (solo admins)
    Route::post('/fix-storage-link', [App\Http\Controllers\Admin\DashboardController::class, 'fixStorageLink'])->name('admin.fix-storage-link');

    // Platforms
    Route::resource('platforms', App\Http\Controllers\Admin\PlatformController::class)->names([
        'index' => 'admin.platforms.index',
        'create' => 'admin.platforms.create',
        'store' => 'admin.platforms.store',
        'edit' => 'admin.platforms.edit',
        'update' => 'admin.platforms.update',
        'destroy' => 'admin.platforms.destroy',
    ]);

    // Platform Subjects
    Route::prefix('platforms/{platform}/subjects')->name('admin.platforms.subjects.')->group(function () {
        Route::get('/', [App\Http\Controllers\Admin\PlatformController::class, 'subjects'])->name('index');
        Route::post('/', [App\Http\Controllers\Admin\PlatformController::class, 'storeSubject'])->name('store');
        Route::delete('/{subject}', [App\Http\Controllers\Admin\PlatformController::class, 'destroySubject'])->name('destroy');
    });

    // Servers (was Email Accounts)
    Route::resource('servers', App\Http\Controllers\Admin\ServerController::class)->names([
        'index' => 'admin.servers.index',
        'create' => 'admin.servers.create',
        'store' => 'admin.servers.store',
        'edit' => 'admin.servers.edit',
        'update' => 'admin.servers.update',
        'destroy' => 'admin.servers.destroy',
    ]);

    // Test IMAP connection for server creation
    Route::post('/servers/test-connection', [App\Http\Controllers\Admin\ServerController::class, 'testConnection'])->name('admin.servers.test-connection');
    Route::get('/servers/{server}/test-connection', [App\Http\Controllers\Admin\ServerController::class, 'testConnectionById'])->name('admin.servers.test-connection-by-id');

    // Autorizar/desautorizar servidor (solo admins)
    Route::post('/servers/{server}/toggle-authorization', [App\Http\Controllers\Admin\ServerController::class, 'toggleAuthorization'])->name('admin.servers.toggle-authorization');

    // Email Accounts (if used separately from servers)
    Route::resource('email-accounts', App\Http\Controllers\Admin\EmailAccountController::class)->names([
        'index' => 'admin.email-accounts.index',
        'create' => 'admin.email-accounts.create',
        'store' => 'admin.email-accounts.store',
        'edit' => 'admin.email-accounts.edit',
        'update' => 'admin.email-accounts.update',
        'destroy' => 'admin.email-accounts.destroy',
    ]);

    // Test IMAP connection
    Route::post('/email-accounts/{emailAccount}/test-connection', [App\Http\Controllers\Admin\EmailAccountController::class, 'testConnection'])->name('admin.email-accounts.test-connection');
    Route::get('/email-accounts/{emailAccount}/test-connection-ajax', [App\Http\Controllers\Admin\EmailAccountController::class, 'testConnectionAjax'])->name('admin.email-accounts.test-connection-ajax');

    // Allowed Emails Mass Upload
    Route::get('/allowed-emails/mass-upload', [App\Http\Controllers\Admin\AllowedEmailController::class, 'massUpload'])->name('admin.allowed-emails.mass-upload');
    Route::post('/allowed-emails/mass-upload', [App\Http\Controllers\Admin\AllowedEmailController::class, 'massStore'])->name('admin.allowed-emails.mass-store');

    // Allowed Emails
    Route::resource('allowed-emails', App\Http\Controllers\Admin\AllowedEmailController::class)->names([
        'index' => 'admin.allowed-emails.index',
        'create' => 'admin.allowed-emails.create',
        'store' => 'admin.allowed-emails.store',
        'edit' => 'admin.allowed-emails.edit',
        'update' => 'admin.allowed-emails.update',
        'destroy' => 'admin.allowed-emails.destroy',
    ]);

    // Queries
    Route::resource('queries', App\Http\Controllers\Admin\QueryController::class)->names([
        'index' => 'admin.queries.index',
        'show' => 'admin.queries.show',
        'destroy' => 'admin.queries.destroy',
    ]);

    // Truncate all queries
    Route::post('/queries/truncate', [App\Http\Controllers\Admin\QueryController::class, 'truncate'])->name('admin.queries.truncate');

    // Profile (Accessible by both Admin and User/Franchise)
    Route::get('/profile', [App\Http\Controllers\Admin\ProfileController::class, 'edit'])->name('admin.profile.edit');
    Route::put('/profile', [App\Http\Controllers\Admin\ProfileController::class, 'update'])->name('admin.profile.update');

    // Rutas exclusivas para el Súper Administrador
    Route::middleware([\App\Http\Middleware\CheckUserRole::class.':admin'])->group(function () {
        Route::resource('users', App\Http\Controllers\Admin\UserController::class)->names([
            'index' => 'admin.users.index',
            'create' => 'admin.users.create',
            'store' => 'admin.users.store',
            'edit' => 'admin.users.edit',
            'update' => 'admin.users.update',
            'destroy' => 'admin.users.destroy',
        ]);

        Route::resource('franchise-plans', App\Http\Controllers\Admin\FranchisePlanController::class)->names([
            'index' => 'admin.franchise-plans.index',
            'create' => 'admin.franchise-plans.create',
            'store' => 'admin.franchise-plans.store',
            'edit' => 'admin.franchise-plans.edit',
            'update' => 'admin.franchise-plans.update',
            'destroy' => 'admin.franchise-plans.destroy',
        ]);

        // IP Bans (Anti-Spam)
        Route::get('/ip-bans', [App\Http\Controllers\Admin\IpBanController::class, 'index'])->name('admin.ip-bans.index');
        Route::delete('/ip-bans/{ipBan}', [App\Http\Controllers\Admin\IpBanController::class, 'destroy'])->name('admin.ip-bans.destroy');
        
        // --- SUPER ADMIN ONLY (ID = 1) ---
        Route::middleware([\App\Http\Middleware\CheckSuperAdmin::class])->group(function () {
            Route::get('/licenses', \App\Livewire\Admin\LicenseManager::class)->name('admin.licenses.index');
        });
        // ---------------------------------
    });

    // Clients
    Route::resource('clients', App\Http\Controllers\Admin\ClientController::class)->names([
        'index' => 'admin.clients.index',
        'create' => 'admin.clients.create',
        'store' => 'admin.clients.store',
        'edit' => 'admin.clients.edit',
        'update' => 'admin.clients.update',
        'destroy' => 'admin.clients.destroy',
    ]);
    
    // Warranties
    Route::resource('warranties', App\Http\Controllers\Admin\WarrantyController::class)->only(['index', 'update', 'show'])->names([
        'index' => 'admin.warranties.index',
        'update' => 'admin.warranties.update',
        'show' => 'admin.warranties.show',
    ]);

    // Reset client query count
    Route::post('/clients/{client}/reset-queries', [App\Http\Controllers\Admin\ClientController::class, 'resetQueryCount'])->name('admin.clients.reset-queries');

    // Activate/Deactivate client
    Route::post('/clients/{client}/activate', [App\Http\Controllers\Admin\ClientController::class, 'activate'])->name('admin.clients.activate');
    Route::post('/clients/{client}/deactivate', [App\Http\Controllers\Admin\ClientController::class, 'deactivate'])->name('admin.clients.deactivate');


    // 2FA Routes (Admin/User)
    Route::post('/2fa/enable', [App\Http\Controllers\TwoFactorController::class, 'enable'])->name('admin.2fa.enable');
    Route::post('/2fa/confirm', [App\Http\Controllers\TwoFactorController::class, 'confirm'])->name('admin.2fa.confirm');
    Route::post('/2fa/disable', [App\Http\Controllers\TwoFactorController::class, 'disable'])->name('admin.2fa.disable');

    // API Keys Management
    Route::post('/api-keys', [App\Http\Controllers\Admin\ApiKeyController::class, 'generate'])->name('admin.api-keys.generate');
    Route::delete('/api-keys/{token}', [App\Http\Controllers\Admin\ApiKeyController::class, 'revoke'])->name('admin.api-keys.revoke');
});

// Client Routes
Route::prefix('client')->name('client.')->group(function () {
    // Logout route (uses unified AuthController)
    Route::post('/logout', [AuthController::class, 'logout'])->name('logout');

    // Protected Client Routes
    Route::middleware('auth:client')->group(function () {
        Route::get('/dashboard', [App\Http\Controllers\Client\ClientAuthController::class, 'dashboard'])->name('dashboard');
        Route::get('/profile', [App\Http\Controllers\Client\ClientAuthController::class, 'profile'])->name('profile');
        Route::put('/profile', [App\Http\Controllers\Client\ClientAuthController::class, 'updateProfile'])->name('profile.update');
        Route::get('/query', [App\Http\Controllers\Client\CodeQueryController::class, 'index'])->name('query');
    Route::get('/query/code', [App\Http\Controllers\Client\CodeQueryController::class, 'getTempCode'])->name('query.code');
    Route::get('/query/limit', [App\Http\Controllers\Client\ClientAuthController::class, 'getLimitStatus'])->name('query.limit');

    // IMAP Diagnostic routes
    Route::post('/diagnose/imap', [App\Http\Controllers\Client\CodeQueryController::class, 'diagnoseImap'])->name('diagnose.imap');
    Route::get('/emails/recent', [App\Http\Controllers\Client\CodeQueryController::class, 'listRecentEmails'])->name('emails.recent');
    Route::get('/emails/match-subjects', [App\Http\Controllers\Client\CodeQueryController::class, 'matchSubjects'])->name('emails.match-subjects');
    Route::get('/emails/by-platform', [App\Http\Controllers\Client\CodeQueryController::class, 'getEmailsByPlatform'])->name('emails.by-platform');
    
    // Warranties
    // API Keys
    Route::get('/api-keys', [App\Http\Controllers\Client\ApiKeyController::class, 'index'])->name('client.api-keys.index');
    Route::post('/api-keys', [App\Http\Controllers\Client\ApiKeyController::class, 'store'])->name('client.api-keys.store');
    Route::delete('/api-keys/{id}', [App\Http\Controllers\Client\ApiKeyController::class, 'destroy'])->name('client.api-keys.destroy');

    Route::resource('warranties', App\Http\Controllers\Client\WarrantyController::class)->names('client.warranties');
    });
});
